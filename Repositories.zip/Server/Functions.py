import os
import shutil
import zipfile

def emptyFolder(folder):
    for file in os.listdir(folder):
        file = os.path.join(folder, file)
        if os.path.isdir(file):
            shutil.rmtree(file)
        else:
            os.remove(file)
    return folder

def getFolderSize(folder):
    total_size = os.path.getsize(folder)
    for item in os.listdir(folder):
        itempath = os.path.join(folder, item)
        if os.path.isfile(itempath):
            total_size += os.path.getsize(itempath)
        elif os.path.isdir(itempath):
            total_size += getFolderSize(itempath)
    return total_size

def toBool(string):
    if string.lower() == "true":
        return True
    return False

def zip(target, destination):
    with zipfile.ZipFile((os.path.join(destination, os.path.split(target)[1]) + ".zip"), 'w',
                         zipfile.ZIP_DEFLATED) as zipped:
        for root, dirs, files in os.walk(target):
            for folder in dirs:
                zipped.write(os.path.join(root, folder), arcname=os.path.join(root.replace(target, ""), folder))
            for entry in files:
                zipped.write(os.path.join(root, entry), arcname=os.path.join(root.replace(target, ""), entry))
    zipped.close()
    return zipped.filename

def unzip(target, destination):
    with zipfile.ZipFile(target, 'r') as zipped:
        files_list = zipped.infolist()
        for file in files_list:
            new_file_name = file.filename
            copy = 0
            while os.path.isfile(os.path.join(destination, new_file_name)):
                copy += 1
                new_file_name = os.path.splitext(file.filename)[0] + "(" + str(copy) + ")" + os.path.splitext(file.filename)[1]
            file.filename = new_file_name
            zipped.extract(file, destination)
    zipped.close()
    os.remove(target)