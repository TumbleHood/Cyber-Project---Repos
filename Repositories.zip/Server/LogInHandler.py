import pymysql
import os
import datetime
import shutil
import RepoHandler
import Functions

class Handler:
    def __init__(self, socket):
        self.server = SocketClass(socket)
        self.username = ""
        self.functions = {"create": self.Create,
                          "list": self.List,
                          "enter": self.Enter,
                          "rename": self.Rename,
                          "delete": self.Delete,
                          "disconnect": self.Disconnect}

    def StartHandle(self):
        while not os.path.split(os.getcwd())[1] == "Server":
            os.chdir("..")
        try:
            fullname, self.username = self.HandleLogIn()
        except ConnectionResetError:
            self.server.Close()
            print("Disconnection")
            return
        print("New User Connection: " + fullname)
        newUserfolder = os.path.join(os.getcwd(), os.path.join("repository", self.username))
        if not os.path.isdir(newUserfolder):
            os.mkdir(newUserfolder)
        if not os.path.isdir(os.path.join(newUserfolder, "temp")):
            os.mkdir(os.path.join(newUserfolder, "temp"))
        self.server.WriteMessage(fullname)

        while True:
            try:
                action = self.server.ReadMessage().lower()
                self.functions[action](newUserfolder)
            except ConnectionResetError:
                print("Disconnection From User: " + fullname)
                self.server.Close()
                return
            except OSError:
                print("Disconnection From User: " + fullname)
                self.server.Close()
                return


    def Create(self, newUserfolder):
        repository = self.server.ReadMessage()
        if not os.path.isdir(os.path.join(newUserfolder, repository)):
            os.mkdir(os.path.join(newUserfolder, repository))
            handler = RepoHandler.ClientHandler(self.server.server, newUserfolder, repository)
            done = handler.HandleCommands()
            self.server.WriteMessage("THIS ONE IS SENT IN ORDER TO CRASH A FUNCTION")

    def List(self, newUserfolder):
        names = ["\n"]
        sizes = ["\n"]
        dates = ["\n"]
        for file in os.listdir(newUserfolder):
            if not file == "temp":
                names.append(file)
                file = os.path.join(newUserfolder, file)
                sizes.append(str(os.path.getsize(file))) if os.path.isfile(file) else sizes.append(str(Functions.getFolderSize(file)))
                dates.append(str(datetime.datetime.fromtimestamp(os.path.getmtime(file))).split(".")[0])
        self.server.WriteMessage("?".join(names))
        self.server.WriteMessage("?".join(sizes))
        self.server.WriteMessage("?".join(dates))

    def Enter(self, newUserfolder):
        repository = os.path.join(newUserfolder, self.server.ReadMessage())
        handler = RepoHandler.ClientHandler(self.server.server, newUserfolder, repository)
        try:
            done = handler.HandleCommands()
        except ConnectionResetError:
            return
        self.server.WriteMessage("THIS ONE IS SENT IN ORDER TO CRASH A FUNCTION")

    def Rename(self, newUserfolder):
        array = self.server.ReadMessage().split("\n")
        oldName = array[0]
        newName = array[1]
        copy = 0
        newNewName = os.path.join(newUserfolder, newName)
        while os.path.exists(newNewName):
            copy += 1
            newNewName = os.path.join(newUserfolder, newName + "(" + str(copy) + ")")
        os.rename(os.path.join(newUserfolder, oldName), newNewName)
        self.server.WriteMessage("OK")

    def Delete(self, newUserfolder):
        tryPassword = self.server.ReadMessage()
        if self.LogIn(self.username, tryPassword):
            self.server.WriteMessage("TRUE")
            repo = self.server.ReadMessage()
            shutil.rmtree(os.path.join(newUserfolder, repo))
            self.server.WriteMessage("OK")
        else:
            self.server.WriteMessage("FALSE")

    def Disconnect(self, newUserfolder):
        self.server.Close()
        print("Disconnection")
        return

    def HandleLogIn(self):
        while True:
            if self.server.ReadMessage() == "LOGIN":
                array = self.server.ReadMessage().split("?")
                username = array[0]
                password = array[1]
                if self.LogIn(username, password):
                    self.server.WriteMessage("TRUE")
                    return self.GetUsername(username)
                else:
                    self.server.WriteMessage("FALSE")
            else:
                array = self.server.ReadMessage().split("?")
                username = array[0]
                password = array[1]
                email = array[2]
                if self.Register(username, password, email):
                    self.server.WriteMessage("TRUE")
                else:
                    self.server.WriteMessage("FALSE")

    def LogIn(self, username, password):
        db = pymysql.connect(host="localhost", user="root", password="GuyCyberProject", database='repos')
        cursor = db.cursor()
        command = f"""SELECT password FROM repos.users WHERE username = '{username}';"""
        try:
            cursor.execute(command)
            db_pass = cursor.fetchone()[0]
            return db_pass == password
        except:
            return False

    def Register(self, username, password, fullname):
        db = pymysql.connect(host="localhost", user="root", password="GuyCyberProject", database='repos')
        cursor = db.cursor()
        command = f"""SELECT password FROM repos.users WHERE username = '{username}';"""
        cursor.execute(command)
        try:
            db_test = cursor.fetchone()[0]
            return False
        except:
            command = f"""INSERT INTO repos.users VALUES ('{username}', '{password}', '{fullname}');"""
            cursor.execute(command)
            db.commit()
            return True

    def GetUsername(self, username):
        db = pymysql.connect(host="localhost", user="root", password="GuyCyberProject", database='repos')
        cursor = db.cursor()
        command = f"""SELECT fullname FROM repos.users WHERE username = '{username}';"""
        try:
            cursor.execute(command)
            db_fullname = cursor.fetchone()[0]
            if not db_fullname == "":
                return db_fullname, username
            return username, username
        except:
            return username, username

class SocketClass:
    def __init__(self, socket):
        self.server = socket

        self.encoder = {"upload": "1".encode(),
                        "download": "2".encode(),
                        "display": "3".encode(),
                        "new": "4".encode(),
                        "rename": "5".encode(),
                        "delete": "6".encode(),
                        "exit": "7".encode()}

        self.decoder1 = {"1".encode(): "command",
                         "2".encode(): "data"}

        self.decoder2 = {"1".encode(): "upload",
                         "2".encode(): "download",
                         "3".encode(): "display",
                         "4".encode(): "new",
                         "5".encode(): "rename",
                         "6".encode(): "delete",
                         "7".encode(): "exit"}

    def Close(self):
        self.server.close()

    def Write(self, command, message):
        if not type(message) == bytes:
            message = message.encode()
        message = self.encoder[command] + message
        self.server.sendall(len(message).to_bytes(4, 'big'))
        self.server.sendall(message)

    def Read(self):
        message_length = int.from_bytes(self.server.recv(4), 'big')
        message = self.server.recv(message_length)
        function = self.decoder1[message[:1]]
        command = self.decoder2[message[1:2]]
        content = message[2:]
        return [function, command, content]

    def WriteMessage(self, message):
        message = message.encode()
        self.server.sendall(len(message).to_bytes(4, 'big'))
        self.server.sendall(message)

    def ReadMessage(self):
        message_length = int.from_bytes(self.server.recv(4), 'big')
        message = self.server.recv(message_length)
        return message.decode()