import Functions
from threading import Thread
from threading import Lock
from queue import Queue
import os
import shutil
import datetime
import LogInHandler

class ClientHandler:
    def __init__(self, socket, user_name, repository_name):
        os.chdir(user_name)
        self.server = LogInHandler.SocketClass(socket)

        self.upload_queue = Queue()
        self.download_queue = Queue()
        self.other_queue = Queue()

        self.upload_data = Queue()
        self.download_data = Queue()
        self.other_data = Queue()

        self.other_commands = {"display": self.Display,
                               "new": self.New,
                               "rename": self.Rename,
                               "delete": self.Delete,
                               "exit": self.Exit}

        self.user = user_name
        self.repository = repository_name
        self.exit = False
        self.exit_lock = Lock()

        self.temp_folder = Functions.emptyFolder("temp")

        Thread(target=ClientHandler.HandleQueues, args=(self,)).start()

    def HandleCommands(self):
        while not self.exit:
            try:
                message = self.server.Read()
            except ConnectionResetError:
                print("Sudden Disconnection - ConnectionResetError")
                with self.exit_lock:
                    self.exit = True
                return
            except KeyError:
                print("Sudden Disconnection - KeyError")
                with self.exit_lock:
                    self.exit = True
                return
            except ConnectionAbortedError:
                print("Sudden Disconnection - ConnectionAbortedError")
                with self.exit_lock:
                    self.exit = True
                return
            function = message[0]
            command = message[1]
            content = message[2]
            if function == "command":
                if command == "upload":
                    self.upload_queue.put(content)
                elif command == "download":
                    self.download_queue.put(content)
                else:
                    self.other_queue.put([command, content])
            elif function == "data":
                if command == "upload":
                    self.upload_data.put(content)
                elif command == "download":
                    self.download_data.put(content)
                else:
                    self.other_data.put([command, content])

    def HandleQueues(self):
        uploading = False
        downloading = False
        othering = False

        upload_thread = Thread(target=ClientHandler.HandleUploads, args=(self,))
        download_thread = Thread(target=ClientHandler.HandleDownloads, args=(self,))
        other_thread = Thread(target=ClientHandler.HandleOthers, args=(self,))

        while True:
            with self.exit_lock:
                if self.exit:
                    return

            if not self.upload_queue.empty() and not uploading:
                uploading = True
                upload_thread.start()

            if not self.download_queue.empty() and not downloading:
                downloading = True
                download_thread.start()

            if not self.other_queue.empty() and not othering:
                othering = True
                other_thread.start()

            if not upload_thread.isAlive() and uploading:
                upload_thread.join()
                upload_thread = Thread(target=ClientHandler.HandleUploads, args=(self,))
                uploading = False

            if not download_thread.isAlive() and downloading:
                download_thread.join()
                download_thread = Thread(target=ClientHandler.HandleDownloads, args=(self,))
                downloading = False

            if not other_thread.isAlive() and othering:
                other_thread.join()
                other_thread = Thread(target=ClientHandler.HandleOthers, args=(self,))
                othering = False

    def HandleUploads(self):
        self.Upload(self.decodeContent(self.upload_queue.get()))

    def HandleDownloads(self):
        self.Download(self.decodeContent(self.download_queue.get()))

    def HandleOthers(self):
        command = self.other_queue.get()
        self.other_commands[command[0]](self.decodeContent(command[1]))

    def waitForData(self, function):
        if function == "upload":
            while self.upload_data.empty(): pass
            return self.upload_data.get()
        if function == "download":
            while self.download_data.empty(): pass
            return self.download_data.get()
        while True:
            while self.other_queue.empty(): pass
            if self.other_queue.queue[0][0] == function:
                return self.other_queue.get()

    def decodeContent(self, content):
        return content.decode().split("\n")

    def Upload(self, content):
        name = content[0]
        size = int(content[1])
        isFolder = Functions.toBool(content[2])
        destination = content[3]

        if isFolder:
            file = open(os.path.join(self.temp_folder, name), "wb")
        else:
            newName = os.path.join(destination, name)
            copy = 0
            while os.path.isfile(newName):
                copy += 1
                newName = os.path.join(destination,
                                       os.path.splitext(name)[0] + "(" + str(copy) + ")" + os.path.splitext(name)[1])
            file = open(newName, "wb")

        receivedData = 0
        while receivedData < size:
            data = self.waitForData("upload")
            receivedData += len(data)
            file.write(data)
        file.close()

        if isFolder:
            Functions.unzip(os.path.join(self.temp_folder, name), os.path.join(destination, os.path.splitext(name)[0]))
        self.server.Write("upload", "DONE")

    def Download(self, content):
        path = content[0]
        isFolder = os.path.isdir(path)
        if isFolder:
            path = Functions.zip(path, self.temp_folder)
        file = open(path, "rb")
        size = os.path.getsize(path)
        self.server.Write("download", str(size))

        sentData = 0
        while sentData < size:
            data = file.read(65536)
            sentData += len(data)
            self.server.Write("download", data)
        file.close()

        if isFolder:
            os.remove(path)

    def Display(self, content):
        directory = os.listdir(content[0])
        paths = []
        sizes = []
        icons = []
        states = []
        dates = []
        for file in directory:
            file = os.path.join(content[0], file)
            paths.append(file)
            sizes.append(str(os.path.getsize(file))) if os.path.isfile(file) else sizes.append(
                str(Functions.getFolderSize(file)))
            icons.append(os.path.splitext(file)[-1][1:])
            states.append(str(os.path.isdir(file)).lower())
            dates.append(str(datetime.datetime.fromtimestamp(os.path.getmtime(file))).split(".")[0])
        self.server.Write("display", "\n".join(paths))
        self.server.Write("display", "\n".join(sizes))
        self.server.Write("display", "\n".join(icons))
        self.server.Write("display", "\n".join(states))
        self.server.Write("display", "\n".join(dates))

    def New(self, content):
        name = content[0]
        destination = content[1]
        copy = 0
        newName = os.path.join(destination, name)
        while os.path.isdir(newName):
            copy += 1
            newName = os.path.join(destination, name + "(" + str(copy) + ")")
        os.mkdir(newName)

        self.server.Write("new", "DONE")

    def Rename(self, content):
        oldName = content[0]
        newName = content[1]
        copy = 0
        newNewName = os.path.join(os.path.split(oldName)[0], newName + os.path.splitext(oldName)[1])
        while os.path.exists(newNewName):
            copy += 1
            newNewName = os.path.join(os.path.split(oldName)[0],
                                      newName + "(" + str(copy) + ")" + os.path.splitext(oldName)[1])
        os.rename(oldName, newNewName)

        self.server.Write("rename", "DONE")

    def Delete(self, content):
        file = content[0]
        isFolder = Functions.toBool(content[1])

        if isFolder:
            shutil.rmtree(file)
        else:
            os.remove(file)

        self.server.Write("delete", "DONE")

    def Exit(self, content):
        with self.exit_lock:
            self.exit = True
        return