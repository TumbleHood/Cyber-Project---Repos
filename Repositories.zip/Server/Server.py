from threading import Thread
import socket
import pymysql
import LogInHandler

def CreateTable():
    db = pymysql.connect(host="localhost", user="root", password="GuyCyberProject", database='repos')
    cursor = db.cursor()
    command = """CREATE TABLE repos.users(username CHAR(255), password CHAR(255), fullname CHAR(255));"""
    try:
        cursor.execute(command)
        result = cursor.fetchone()[0]
        return True
    except:
        return False

def main():

    server = socket.socket()
    server.bind(('0.0.0.0', 16402))

    server.listen(1)

    client_list = []

    CreateTable()

    while True:
        client, address = server.accept()
        client_list.append((client, address))
        print("New Connection: " + address[0])
        handler = LogInHandler.Handler(client)
        Thread(target=handler.StartHandle).start()

if __name__ == '__main__':
    main()
