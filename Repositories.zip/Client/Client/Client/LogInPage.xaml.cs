﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client
{
    /// <summary>
    /// Interaction logic for LogInPage.xaml
    /// </summary>
    public partial class LogInPage : Page
    {
        public LogInPage()
        {
            InitializeComponent();
        }

        private void showpassword_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            realpassword.Text = password.Password;
            password.Password = "";
            realpassword.Visibility = Visibility.Visible;
        }

        private void showpassword_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            password.Password = realpassword.Text;
            realpassword.Text = "";
            realpassword.Visibility = Visibility.Hidden;
        }

        private void username_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text, @"[^a-zA-Z0-9]");
        }
        private void password_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text, @"[^a-zA-Z0-9]");
        }
        private static bool IsTextAllowed(string Text, string AllowedRegex)
        {
            try
            {
                var regex = new Regex(AllowedRegex);
                return !regex.IsMatch(Text);
            }
            catch
            {
                return true;
            }
        }
    }
}
