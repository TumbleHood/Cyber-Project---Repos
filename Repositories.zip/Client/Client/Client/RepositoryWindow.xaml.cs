﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.Threading;
using Microsoft.WindowsAPICodePack.Dialogs;
using System.IO;
using System.IO.Compression;

namespace Client
{
    /// <summary>
    /// Interaction logic for RepositoryWindow.xaml
    /// </summary>
    public partial class RepositoryWindow : Window
    {
        private Socket client { get; set; }
        private string repository { get; set; }
        private string username { get; set; }

        Queue<string[]> uploadQueue = new Queue<string[]>();
        Queue<string[]> downloadQueue = new Queue<string[]>();
        Queue<(string, string[])> otherQueue = new Queue<(string, string[])>();

        Queue<byte[]> uploadData = new Queue<byte[]>();
        Queue<byte[]> downloadData = new Queue<byte[]>();
        Queue<(string, byte[])> otherData = new Queue<(string, byte[])>();

        public delegate void actions(string[] content);

        Dictionary<string, actions> otherCommands;

        Thread commands;
        Thread queues;

        public static ObservableCollection<Item> display { get; set; }
        public static Window popup = new Window();
        public static List<string> subPaths = new List<string>();
        public static List<Item> selectedFiles = new List<Item>();
        public static string oldCurDir = Directory.GetCurrentDirectory();
        public static Item dragged = new Item();
        public string currentPath
        {
            get
            {
                string currentPath = "";
                foreach (string sub in subPaths)
                    currentPath = Path.Combine(currentPath, sub);
                this.Dispatcher.Invoke(() =>
                {
                    pathBar.Text = currentPath;
                });
                return currentPath;
            }
        }

        public RepositoryWindow(Socket client, string repository, string username)
        {
            this.client = client;
            this.repository = repository;
            this.username = username;
            InitializeComponent();

            DirectoryInfo temp = new DirectoryInfo("temp");
            foreach (FileInfo file in temp.GetFiles())
                file.Delete();
            foreach (DirectoryInfo dir in temp.GetDirectories())
                dir.Delete(true);

            display = new ObservableCollection<Item>();
            subPaths = new List<string>() { repository };

            otherCommands = new Dictionary<string, actions>() { { "display", Display }, { "new", New }, { "rename", Rename }, { "delete", Delete } };

            commands = new Thread(CommandsHandler);
            queues = new Thread(HandleQueues);

            commands.Start();
            queues.Start();

            Display(new string[] { currentPath });
        }
        public void CommandsHandler()
        {
            while (true)
            {
                try
                {
                    (string command, byte[] content) = client.Read();
                    if (command == "upload")
                        uploadData.Enqueue(content);
                    else if (command == "download")
                        downloadData.Enqueue(content);
                    else
                        otherData.Enqueue((command, content));
                }
                catch
                {
                    return;
                }
            }
        }
        public void HandleQueues()
        {
            bool uploading = false;
            bool downloading = false;
            bool othering = false;

            Thread uploadThread = new Thread(() => HandleFunctions("upload"));
            Thread downloadThread = new Thread(() => HandleFunctions("download"));
            Thread otherThread = new Thread(() => HandleFunctions("other"));

            while (true)
            {
                if (uploadQueue.Count() != 0 && !uploading)
                {
                    uploading = true;
                    uploadThread.Start();
                }
                if (downloadQueue.Count() != 0 && !downloading)
                {
                    downloading = true;
                    downloadThread.Start();
                }
                if (otherQueue.Count() != 0 && !othering)
                {
                    othering = true;
                    otherThread.Start();
                }

                if (!uploadThread.IsAlive && uploading)
                {
                    uploadThread.Join();
                    uploadThread = new Thread(() => HandleFunctions("upload"));
                    uploading = false;
                }
                if (!downloadThread.IsAlive && downloading)
                {
                    downloadThread.Join();
                    downloadThread = new Thread(() => HandleFunctions("download"));
                    downloading = false;
                }
                if (!otherThread.IsAlive && othering)
                {
                    otherThread.Join();
                    otherThread = new Thread(() => HandleFunctions("other"));
                    othering = false;
                }
            }
        }
        public void HandleFunctions(string function)
        {
            if (function == "upload")
            {
                while (uploadQueue.Count == 0) { }
                Upload(uploadQueue.Dequeue());
            }
            else if (function == "download")
            {
                while (downloadQueue.Count == 0) { }
                Download(downloadQueue.Dequeue());
            }
            else
            {
                while (otherQueue.Count == 0) { }
                (string command, string[] content) = otherQueue.Dequeue();
                this.Dispatcher.Invoke(() =>
                {
                    DataContext = this;
                    Mouse.OverrideCursor = Cursors.Wait;
                });
                otherCommands[command](content);
                this.Dispatcher.Invoke(() =>
                {
                    DataContext = this;
                    Mouse.OverrideCursor = Cursors.Arrow;
                });
            }
        }
        public byte[] WaitForData(string command)
        {
            if (command == "upload")
            {
                while (uploadData.Count == 0) { }
                return uploadData.Dequeue();
            }
            if (command == "download")
            {
                while (downloadData.Count == 0) { }
                return downloadData.Dequeue();
            }
            while (true)
            {
                while (otherData.Count == 0) { }
                (string function, byte[] content) = otherData.Peek();
                if (function == command)
                {
                    otherData.Dequeue();
                    return content;
                }
            }
        }
        public void PutInQueue(string command, params string[] content)
        {
            if (command == "upload")
                uploadQueue.Enqueue(content);
            else if (command == "download")
                downloadQueue.Enqueue(content);
            else
                otherQueue.Enqueue((command, content));
        }
        private void FileSelected(object sender, SelectionChangedEventArgs e)
        {
            foreach (var file in e.RemovedItems)
            {
                selectedFiles.Remove((Item)file);
            }
            foreach (var file in e.AddedItems)
            {
                selectedFiles.Add((Item)file);
            }
        }
        public static string Zip(string source, string destination)
        {
            ZipFile.CreateFromDirectory(source, Path.Combine(destination, Path.GetFileName(source) + ".zip"));
            return Path.Combine(destination, Path.GetFileName(source) + ".zip");
        }
        public static void Unzip(string source, string destination)
        {
            destination = Path.Combine(destination, Path.GetFileNameWithoutExtension(source));
            Directory.CreateDirectory(destination);
            FileStream stream = new FileStream(source, FileMode.Open);
            using (ZipArchive zipped = new ZipArchive(stream))
            {
                foreach (ZipArchiveEntry entry in zipped.Entries)
                {
                    string name = entry.FullName;
                    if (Path.GetFileName(name) == String.Empty)
                    {
                        Directory.CreateDirectory(Path.Combine(destination, Path.GetDirectoryName(name)));
                    }
                    else
                    {
                        string newName = Path.Combine(destination, name);
                        int copy = 0;
                        while (File.Exists(newName))
                        {
                            copy++;
                            newName = Path.Combine(Path.GetDirectoryName(newName), Path.GetFileNameWithoutExtension(newName) + "(" + copy.ToString() + ")" + Path.GetExtension(newName));
                        }
                        entry.ExtractToFile(newName, false);
                    }
                }
            }
            File.Delete(source);
        }
        public static bool ToBool(string boolean)
        {
            if (boolean.ToLower() == "true")
                return true;
            return false;
        }
        public void Upload(string[] content)
        {
            string file = content[0];
            string pbName = Path.GetFileName(file);

            this.Dispatcher.Invoke(() =>
            {
                pb1.Value = 0;
                pb1.IsIndeterminate = true;
                pb1text.Text = "Preparing \"" + pbName + "\"";
            });

            bool isFolder = Directory.Exists(file);
            if (isFolder)
                file = Zip(file, "temp");
            string name = Path.GetFileName(file);
            int size = File.ReadAllBytes(file).Length;
            string destination = content[1];
            client.Write("command", "upload", name, size.ToString(), isFolder.ToString(), destination);

            int sentData = 0;
            FileStream stream = new FileStream(file, FileMode.Open);
            byte[] data = new byte[65536];

            this.Dispatcher.Invoke(() =>
            {
                pb1.IsIndeterminate = false;
                pb1text.Text = "Uploading \"" + pbName + "\"";
            });
            while (sentData < size)
            {
                int read = stream.Read(data, 0, 65536);
                client.Write("data", "upload", data.Take(read).ToArray());
                sentData += read;

                this.Dispatcher.Invoke(() =>
                {
                    pb1.Value = (((double)sentData / (double)size) * 100);
                });
            }
            stream.Close();

            this.Dispatcher.Invoke(() =>
            {
                pb1.Value = 100;
                pb1.IsIndeterminate = true;
                pb1text.Text = "Finalizing \"" + pbName + "\"";
            });

            if (isFolder && File.Exists(file))
                File.Delete(file);

            if (Encoding.ASCII.GetString(WaitForData("upload")) == "DONE")
                Display(new string[] { currentPath });

            this.Dispatcher.Invoke(() =>
            {
                pb1.IsIndeterminate = false;
                pb1.Value = 0;
                pb1text.Text = "";
            });
        }
        public void Download(string[] content)
        {
            string path = content[0];
            string file = Path.GetFileName(path);
            string pbName = file;
            bool isFolder = ToBool(content[1]);
            string destination = "downloads";

            client.Write("command", "download", path);

            this.Dispatcher.Invoke(() =>
            {
                pb2.Value = 0;
                pb2.IsIndeterminate = true;
                pb2text.Text = "Preparing \"" + pbName + "\"";
            });

            int size = int.Parse(Encoding.ASCII.GetString(WaitForData("download")));
            int receivedData = 0;
            FileStream stream;
            if (isFolder)
                stream = new FileStream(Path.Combine("temp", file + ".zip"), FileMode.CreateNew);
            else
            {
                string newName = Path.Combine(destination, file);
                int copy = 0;
                while (File.Exists(newName))
                {
                    copy++;
                    newName = Path.Combine(destination, Path.GetFileNameWithoutExtension(file) + "(" + copy.ToString() + ")" + Path.GetExtension(file));
                }
                stream = new FileStream(newName, FileMode.CreateNew);
                pbName = newName;
            }

            this.Dispatcher.Invoke(() =>
            {
                pb2.IsIndeterminate = false;
                pb2text.Text = "Downloading \"" + pbName + "\"";
            });

            while (receivedData < size)
            {
                byte[] data = WaitForData("download");
                stream.Write(data, 0, data.Length);
                receivedData += data.Length;

                this.Dispatcher.Invoke(() =>
                {
                    pb2.Value = (((double)receivedData / (double)size) * 100);
                });
            }
            stream.Close();

            this.Dispatcher.Invoke(() =>
            {
                pb2.Value = 100;
                pb2.IsIndeterminate = true;
                pb2text.Text = "Finalizing \"" + pbName + "\"";
            });

            if (isFolder)
                Unzip(Path.Combine("temp", file + ".zip"), destination);

            this.Dispatcher.Invoke(() =>
            {
                pb2.IsIndeterminate = false;
                pb2.Value = 0;
                pb2text.Text = "";
            });
        }
        public void Display(string[] content)
        {
            string directory = content[0];
            client.Write("command", "display", directory);

            string[] paths = Encoding.ASCII.GetString(WaitForData("display")).Split('\n');
            string[] sizes = Encoding.ASCII.GetString(WaitForData("display")).Split('\n');
            string[] icons = Encoding.ASCII.GetString(WaitForData("display")).Split('\n');
            string[] states = Encoding.ASCII.GetString(WaitForData("display")).Split('\n');
            string[] dates = Encoding.ASCII.GetString(WaitForData("display")).Split('\n');
            this.Dispatcher.Invoke(() =>
            {
                display.Clear();
            });
            if (paths[0] != "")
            {
                for (int i = 0; i < paths.Length; i++)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        display.Add(new Item() { path = paths[i], size = sizes[i], extension = icons[i].Replace(".", ""), folder = states[i], date = dates[i] });
                    });
                }
            }
            this.Dispatcher.Invoke(() =>
            {
                DataContext = this;
            });
        }
        public void New(string[] content)
        {
            string name = content[0];
            string destination = content[1];
            client.Write("command", "new", name, destination);

            if (Encoding.ASCII.GetString(WaitForData("new")) == "DONE")
                PutInQueue("display", currentPath);
        }
        public void Rename(string[] content)
        {
            string oldName = content[0];
            string newName = content[1];
            client.Write("command", "rename", oldName, newName);

            if (Encoding.ASCII.GetString(WaitForData("rename")) == "DONE")
                PutInQueue("display", currentPath);
        }
        public void Delete(string[] content)
        {
            string file = content[0];
            string isFolder = content[1];
            client.Write("command", "delete", file, isFolder);

            if (Encoding.ASCII.GetString(WaitForData("delete")) == "DONE")
                PutInQueue("display", currentPath);
        }
        private void Return(object sender, RoutedEventArgs e)
        {
            if (subPaths.Count() > 1)
            {
                subPaths.RemoveAt(subPaths.Count() - 1);
                PutInQueue("display", currentPath);
            }
        }
        private void EnterSubfolder(object sender, RoutedEventArgs e)
        {
            if (selectedFiles.Count() > 0)
            {
                if (selectedFiles.Last().folder == "true")
                {
                    subPaths.Add(selectedFiles.Last().name);
                    PutInQueue("display", currentPath);
                }
            }
        }
        private void Upload_Click(object sender, RoutedEventArgs e)
        {
            Popup popup = new Popup();
            popup.b1.Content = "Files";
            popup.b2.Content = "Folders";
            popup.text.Text = "choose what you want to upload";
            bool? info = popup.ShowDialog();

            var dlg = new CommonOpenFileDialog();
            if ((bool)info)
            {
                dlg.Title = "Select File(s)";
                dlg.IsFolderPicker = false;
            }
            else
            {
                dlg.Title = "Select Folder(s)";
                dlg.IsFolderPicker = true;
            }
            dlg.AddToMostRecentlyUsedList = false;
            dlg.AllowNonFileSystemItems = false;
            dlg.EnsureFileExists = true;
            dlg.EnsurePathExists = true;
            dlg.EnsureReadOnly = false;
            dlg.EnsureValidNames = true;
            dlg.Multiselect = true;
            dlg.ShowPlacesList = true;

            if (dlg.ShowDialog() == CommonFileDialogResult.Ok && dlg.FileNames.Count() > 0)
            {
                foreach (string file in dlg.FileNames)
                {
                    PutInQueue("upload", file, currentPath);
                }
            }
        }
        private void Download_Click(object sender, RoutedEventArgs e)
        {
            foreach (Item file in selectedFiles)
            {
                PutInQueue("download", file.path, file.folder);
            }
        }
        private void New_Click(object sender, RoutedEventArgs e)
        {
            Popup popup = new Popup();
            popup.b1.Content = "Create";
            popup.b2.Content = "Cancel";
            popup.text.Text = "enter new folder name";
            popup.box.Visibility = Visibility.Visible;
            bool? info = popup.ShowDialog();

            if ((bool)info)
            {
                string name = popup.Message;
                PutInQueue("new", name, currentPath);
            }
        }
        private void Rename_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFiles.Count > 0)
            {
                Popup popup = new Popup();
                popup.b1.Content = "Rename";
                popup.b2.Content = "Cancel";
                popup.text.Text = "enter new name";
                popup.box.Visibility = Visibility.Visible;
                popup.box.Text = Path.GetFileNameWithoutExtension(selectedFiles.Last().name);
                bool? info = popup.ShowDialog();

                if ((bool)info)
                {
                    string newName = popup.Message;
                    PutInQueue("rename", selectedFiles.Last().path, newName);
                }
            }
        }
        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFiles.Count > 0)
            {
                Popup popup = new Popup();
                popup.b1.Content = "Delete";
                popup.b2.Content = "Cancel";
                popup.text.Text = "are you sure you want to delete selected files?";
                bool? info = popup.ShowDialog();

                if ((bool)info)
                {
                    foreach (Item file in selectedFiles)
                    {
                        PutInQueue("delete", file.path, file.folder);
                    }
                }
            }
        }
        private void DropFiles(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                foreach (string file in files)
                {
                    PutInQueue("upload", file, currentPath);
                }
            }
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            Directory.SetCurrentDirectory(oldCurDir);
            client.Write("command", "exit", "bye bye");
            client.WriteMessage("THIS ONE IS SENT IN ORDER TO CRASH A FUNCTION");
            MainMenu mainMenu = new MainMenu(client, username);
            mainMenu.Show();
            this.Close();
        }
    }
}
