﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Security.Cryptography;

namespace Client
{
    /// <summary>
    /// Interaction logic for ListPage.xaml
    /// </summary>
    public partial class ListPage : Page
    {
        public static ObservableCollection<Repos> repos { get; set; }
        public static List<Repos> selectedFiles = new List<Repos>();
        public static MainMenu mainMenu = Application.Current.Windows.OfType<MainMenu>().FirstOrDefault();
        public ListPage()
        {
            InitializeComponent();
            repos = new ObservableCollection<Repos>();
            DataContext = this;
            repos.Clear();
            Display();
            DataContext = this;
        }
        public static void Display()
        {
            mainMenu.client.WriteMessage("LIST");

            string[] names = mainMenu.client.ReadMessage().Split('?');
            string[] sizes = mainMenu.client.ReadMessage().Split('?');
            string[] dates = mainMenu.client.ReadMessage().Split('?');
            if (names.Count() > 1)
            {
                for (int i = 1; i < names.Length; i++)
                {
                    repos.Add(new Repos() { name = names[i], size = sizes[i], date = dates[i] });
                }
            }
        }
        public static string Encode(string original)
        {
            byte[] encodedBytes;

            using (var md5 = new MD5CryptoServiceProvider())
            {
                var originalBytes = Encoding.Default.GetBytes(original);
                encodedBytes = md5.ComputeHash(originalBytes);
            }

            return Convert.ToBase64String(encodedBytes);
        }
        private void Repository_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (selectedFiles.Count() > 0)
            {
                mainMenu.client.WriteMessage("ENTER");
                mainMenu.client.WriteMessage(selectedFiles.Last().name);
                RepositoryWindow repository = new RepositoryWindow(mainMenu.client, selectedFiles.Last().name, mainMenu.user);
                repository.Show();
                mainMenu.Close();
            }
        }
        private void FileSelected(object sender, SelectionChangedEventArgs e)
        {
            foreach (var file in e.RemovedItems)
            {
                selectedFiles.Remove((Repos)file);
            }
            foreach (var file in e.AddedItems)
            {
                selectedFiles.Add((Repos)file);
            }
        }

        private void enter_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFiles.Count() > 0)
            {
                mainMenu.client.WriteMessage("ENTER");
                mainMenu.client.WriteMessage(selectedFiles.Last().name);
                RepositoryWindow repository = new RepositoryWindow(mainMenu.client, selectedFiles.Last().name, mainMenu.user);
                repository.Show();
                mainMenu.Close();
            }
        }

        private void rename_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFiles.Count > 0)
            {
                Popup popup = new Popup();
                popup.b1.Content = "Rename";
                popup.b2.Content = "Cancel";
                popup.text.Text = "enter new name";
                popup.box.Visibility = Visibility.Visible;
                popup.box.Text = selectedFiles.Last().name;
                bool? info = popup.ShowDialog();

                if ((bool)info)
                {
                    string newName = popup.Message;
                    mainMenu.client.WriteMessage("RENAME");
                    mainMenu.client.WriteMessage(selectedFiles.Last().name + "\n" + newName);
                }
                mainMenu.client.ReadMessage();
                repos.Clear();
                Display();
            }
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            if (selectedFiles.Count > 0)
            {
                PopupPassword popup = new PopupPassword();
                popup.b1.Content = "Delete";
                popup.b2.Content = "Cancel";
                popup.text.Text = "are you sure you want to delete selected Repos?";
                bool? info = popup.ShowDialog();
                string password = popup.Message;
                string ok = "";

                while ((bool)info)
                {
                    foreach (Repos repo in selectedFiles)
                    {
                        mainMenu.client.WriteMessage("DELETE");
                        mainMenu.client.WriteMessage(Encode(password));
                        ok = mainMenu.client.ReadMessage();
                        if (ok == "TRUE")
                        {
                            mainMenu.client.WriteMessage(repo.name);
                            mainMenu.client.ReadMessage();
                        }
                        info = false;
                    }
                    if (ok == "FALSE")
                    {
                        popup = new PopupPassword();
                        popup.b1.Content = "Delete";
                        popup.b2.Content = "Cancel";
                        popup.text.Text = "wrong password";
                        info = popup.ShowDialog();
                        password = popup.Message;
                        ok = "";
                    }
                }
                repos.Clear();
                Display();
            }
        }

        private void exit_Click(object sender, RoutedEventArgs e)
        {
            mainMenu.Frame.Navigate(new MainPage());
        }
    }
}
