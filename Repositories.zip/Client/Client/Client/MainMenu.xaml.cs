﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Client
{
    /// <summary>
    /// Interaction logic for MainMenu.xaml
    /// </summary>
    public partial class MainMenu : Window
    {
        public Socket client { get; set; }
        public string user { get; set; }
        public MainMenu(Socket client, string name)
        {
            this.user = name;
            this.client = client;
            InitializeComponent();
            Frame.NavigationService.Navigate(new MainPage());
            User.Text = "Logged in as: " + user;
        }
    }
}