﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Client
{
    /// <summary>
    /// Interaction logic for PopupPassword.xaml
    /// </summary>
    public partial class PopupPassword : Window
    {
        MainMenu mainMenu = Application.Current.Windows.OfType<MainMenu>().FirstOrDefault();
        public PopupPassword()
        {
            InitializeComponent();
        }
        public string Message { get { return box.Password; } }
        private void Op1(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
        private void Op2(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void box_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsTextAllowed(e.Text, @"[^a-zA-Z0-9]");
        }
        private static bool IsTextAllowed(string Text, string AllowedRegex)
        {
            try
            {
                var regex = new Regex(AllowedRegex);
                return !regex.IsMatch(Text);
            }
            catch
            {
                return true;
            }
        }
    }
}
