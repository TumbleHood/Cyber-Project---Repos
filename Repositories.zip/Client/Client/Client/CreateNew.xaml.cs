﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Client
{
    /// <summary>
    /// Interaction logic for CreateNew.xaml
    /// </summary>
    public partial class CreateNew : Page
    {
        MainMenu mainMenu = Application.Current.Windows.OfType<MainMenu>().FirstOrDefault();
        public CreateNew()
        {
            InitializeComponent();
        }
        private void create_Click(object sender, RoutedEventArgs e)
        {
            mainMenu.client.WriteMessage("CREATE");
            mainMenu.client.WriteMessage(name.Text);
            RepositoryWindow repository = new RepositoryWindow(mainMenu.client, name.Text, mainMenu.user);
            repository.Show();
            mainMenu.Close();
        }
        private void back_Click(object sender, RoutedEventArgs e)
        {
            mainMenu.Frame.NavigationService.Navigate(new MainPage());
        }
    }
}
