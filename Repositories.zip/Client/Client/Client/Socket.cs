﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;
using System.Threading;

namespace Client
{
    public class Socket
    {
        TcpClient client;
        Dictionary<byte, string> decoder = new Dictionary<byte, string> { { Encoding.ASCII.GetBytes("1")[0], "upload" }, { Encoding.ASCII.GetBytes("2")[0], "download" }, { Encoding.ASCII.GetBytes("3")[0], "display" }, { Encoding.ASCII.GetBytes("4")[0], "new" }, { Encoding.ASCII.GetBytes("5")[0], "rename" }, { Encoding.ASCII.GetBytes("6")[0], "delete" }, { Encoding.ASCII.GetBytes("7")[0], "exit" } };
        Dictionary<string, byte[]> encoder2 = new Dictionary<string, byte[]> { { "upload", Encoding.ASCII.GetBytes("1") }, { "download", Encoding.ASCII.GetBytes("2") }, { "display", Encoding.ASCII.GetBytes("3") }, { "new", Encoding.ASCII.GetBytes("4") }, { "rename", Encoding.ASCII.GetBytes("5") }, { "delete", Encoding.ASCII.GetBytes("6") }, { "exit", Encoding.ASCII.GetBytes("7") } };
        Dictionary<string, byte[]> encoder1 = new Dictionary<string, byte[]> { { "command", Encoding.ASCII.GetBytes("1") }, { "data", Encoding.ASCII.GetBytes("2") } };
        public Socket(string ip, int port)
        {
            client = new TcpClient();
            while (true)
            {
                try
                {
                    client.Connect(ip, port);
                    return;
                }
                catch
                {
                    Thread.Sleep(500);
                }
            }
        }
        public void Disconnect()
        {
            this.WriteMessage("DISCONNECT");
            client.Close();
        }
        public void Write(string function, string command, params string[] content)
        {
            byte[] message = encoder1[function].Concat(encoder2[command]).Concat(Encoding.ASCII.GetBytes(String.Join("\n", content))).ToArray();
            NetworkStream stream = client.GetStream();
            stream.Write(BitConverter.GetBytes(IPAddress.HostToNetworkOrder(message.Length)), 0, sizeof(int));
            stream.Flush();
            stream.Write(message, 0, message.Length);
            stream.Flush();
        }
        public void Write(string function, string command, byte[] content)
        {
            byte[] message = encoder1[function].Concat(encoder2[command]).Concat(content).ToArray();
            NetworkStream stream = client.GetStream();
            stream.Write(BitConverter.GetBytes(IPAddress.HostToNetworkOrder(message.Length)), 0, sizeof(int));
            stream.Flush();
            stream.Write(message, 0, message.Length);
            stream.Flush();
        }
        public (string, byte[]) Read()
        {
            NetworkStream stream = client.GetStream();
            byte[] message_length = new byte[sizeof(int)];
            stream.Read(message_length, 0, sizeof(int));
            int length = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(message_length, 0));
            byte[] message = new byte[length];
            stream.Read(message, 0, length);
            string command = decoder[message.Take(1).ToArray()[0]];
            byte[] content = message.Skip(1).ToArray();
            return (command, content);
        }

        public void WriteMessage(string message)
        {
            byte[] buffer = Encoding.ASCII.GetBytes(message);
            NetworkStream stream = client.GetStream();
            stream.Write(BitConverter.GetBytes(IPAddress.HostToNetworkOrder(buffer.Length)), 0, sizeof(int));
            stream.Flush();
            stream.Write(buffer, 0, buffer.Length);
            stream.Flush();
        }
        public string ReadMessage()
        {
            NetworkStream stream = client.GetStream();
            byte[] message_length = new byte[sizeof(int)];
            stream.Read(message_length, 0, sizeof(int));
            int length = IPAddress.NetworkToHostOrder(BitConverter.ToInt32(message_length, 0));
            byte[] message = new byte[length];
            stream.Read(message, 0, length);
            return Encoding.ASCII.GetString(message);
        }
    }
}