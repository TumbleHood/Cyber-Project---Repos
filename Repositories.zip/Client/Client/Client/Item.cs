﻿using System.IO;

namespace Client
{
    public class Item
    {
        public string path { get; set; }
        public string size { get; set; }
        public string name => Path.GetFileName(path);
        public string extension { get; set; }
        public string icon => GetIcon(extension);
        public string folder { get; set; } = "false";
        public string date { get; set; }
        public string GetIcon(string extension)
        {
            string cd = Path.Combine(Directory.GetCurrentDirectory(), "Client\\Client\\icons");
            if (folder == "true")
                return Path.Combine(cd, "folder.jpg");
            if (File.Exists(Path.Combine(cd, extension + ".jpg")))
                return Path.Combine(cd, extension + ".jpg");
            return Path.Combine(cd, "unknown.jpg");
        }
    }
}