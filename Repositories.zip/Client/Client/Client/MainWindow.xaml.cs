﻿using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Security.Cryptography;
using System.Text;
using System;

namespace Client
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Socket client;
        static RegisterPage register = new RegisterPage();
        static LogInPage mainPage = new LogInPage();
        static bool inMainPage = true;

        public MainWindow()
        {
            Directory.SetCurrentDirectory(@"..\..\..\..\");
            InitializeComponent();
            this.Show();
            client = new Socket("127.0.0.1", 16402);
            text.Text = "";
            right.Visibility = Visibility.Visible;
            left.Visibility = Visibility.Visible;
            Frame.Navigate(mainPage);
        }
        public static bool ToBool(string boolean)
        {
            if (boolean.ToUpper() == "TRUE")
                return true;
            return false;
        }
        public static string Encode(string original)
        {
            byte[] encodedBytes;

            using (var md5 = new MD5CryptoServiceProvider())
            {
                var originalBytes = Encoding.Default.GetBytes(original);
                encodedBytes = md5.ComputeHash(originalBytes);
            }

            return Convert.ToBase64String(encodedBytes);
        }
        private void left_Click(object sender, RoutedEventArgs e)
        {
            text.Text = "";
            if (inMainPage)
            {
                Frame.Navigate(register);
                left.Content = "Return";
                right.Content = "Create Account";
                inMainPage = false;
            }
            else
            {
                Frame.Navigate(mainPage);
                left.Content = "Register";
                right.Content = "Log In";
                inMainPage = true;
            }
        }

        private void right_Click(object sender, RoutedEventArgs e)
        {
            if (inMainPage)
            {
                client.WriteMessage("LOGIN");
                client.WriteMessage(mainPage.username.Text + "?" + Encode(mainPage.password.Password));
                if (ToBool(client.ReadMessage()))
                {
                    text.Text = "Successfully logged in :)";
                    Thread.Sleep(150);
                    MainMenu mainMenu = new MainMenu(client, client.ReadMessage());
                    mainMenu.Show();
                    mainPage.password.Password = "";
                    this.Close();
                }
                else
                    text.Text = "Wrong username or password :(";
            }
            else
            {
                if (register.username.Text.Length == 0 && register.password.Password.Length == 0)
                    text.Text = "Username/Password must have more than 0 characters in them :(";
                else
                {
                    if (register.password.Password != register.confirmpassword.Password)
                        text.Text = "Passwords dont match :(";
                    else
                    {

                        client.WriteMessage("REGISTER");
                        client.WriteMessage(register.username.Text + "?" + Encode(register.password.Password) + "?" + register.fullname.Text);
                        if (ToBool(client.ReadMessage()))
                        {
                            Frame.Navigate(mainPage);
                            mainPage.username.Text = register.username.Text;
                            left.Content = "Register";
                            right.Content = "Log In";
                            inMainPage = true;
                            text.Text = "Successfully created new user :)";
                        }

                        else
                            text.Text = "Username already taken :(";
                    }
                }
            }
        }
    }
}